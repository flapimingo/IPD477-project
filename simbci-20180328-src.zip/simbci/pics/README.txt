
The script will dump all pictures here after the end of the run.


