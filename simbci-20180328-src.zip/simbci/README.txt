
simBCI - A framework for simulating BCI data and experiments

The framework was originally developed in the scope of a collaborative 
research project between Inria and IMT-Atlantique (ex. Telecom Bretagne). 
The project was funded by the CominLabs LABEX project SABRE.

See doc/README.txt for a brief description of the package.

See doc/AUTHORS.txt for credits

