

function feats = squared_extract(dataset, modelExtractor)

	feats = (dataset.X).^2;

