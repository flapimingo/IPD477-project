
This folder contains miscellaneous old code that doesn't work with the current conventions of the 
platform. If they are fixed, they should be named with the current conventions and moved to proper location.


