
function [model,feats] = squared_train(trainData, params)

	model = [];
	model.params = params;

	feats = [];

