
function [sourceActivity,details,params] = gen_zeroes( sizeof, varargin)
% Returns empty data

	sourceActivity = zeros(sizeof);

	details = [];
	params = [];

end

