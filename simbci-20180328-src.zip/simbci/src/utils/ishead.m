function val = ishead( x )
% Is the input a class called 'core_head'?

	val = isa(x,'core_head');

end

