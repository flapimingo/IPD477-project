function version = platform_version( )
% Returns the current version number

	version=[];
	version.software = 'SABRE';
	version.major = 0;
	version.minor = 1;
	version.patch = 0;

end

