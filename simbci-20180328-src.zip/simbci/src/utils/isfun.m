function val = isfun( x )
% Is the input a function handle?

 val = isa(x,'function_handle');

end

