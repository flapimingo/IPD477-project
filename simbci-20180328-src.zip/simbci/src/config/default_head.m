
headParams = {'filename', 'sabre:/models/leadfield-sphere.mat', ...
		'centerAndScale', true};
	
