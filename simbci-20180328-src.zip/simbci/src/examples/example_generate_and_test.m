
% 
% This example is elsewhere:
%
% See also ..\classifytest.m
%

