
BCI Simulator will store its intermediate results here. Each experiment will create its own
folder with the experiment id as the folder name.

