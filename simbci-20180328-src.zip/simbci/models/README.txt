
This folder can contain leadfield (head) models.


