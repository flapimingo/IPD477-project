 

function feats = sloreta_inverse_extract(modelExtractor, dataset)

	feats = extract_features_inverse( modelExtractor, dataset );

