
These are various third-party components (dependencies) that the framework may use. 
Their licenses should be compatible with that of the framework.

For credits, please consult the component in question.


