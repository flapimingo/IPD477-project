
This folder can contain imported leadfields from other systems.


